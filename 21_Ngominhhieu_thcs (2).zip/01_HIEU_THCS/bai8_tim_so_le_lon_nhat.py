def largest_odd(a, b, c):
    odds = [x for x in (a,b,c) if x % 2 != 0]
    if not odds:
        return None  # không có số lẻ
    return max(odds)

if __name__ == '__main__':
    print(largest_odd(2,4,6))  # None
    print(largest_odd(3,5,2))  # 5
