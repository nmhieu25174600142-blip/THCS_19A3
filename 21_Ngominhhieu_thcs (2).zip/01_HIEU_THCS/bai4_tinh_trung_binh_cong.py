def trung_binh_cong(a, b, c):
    return (a + b + c) / 3.0

if __name__ == '__main__':
    print(trung_binh_cong(1,2,3))  # 2.0
