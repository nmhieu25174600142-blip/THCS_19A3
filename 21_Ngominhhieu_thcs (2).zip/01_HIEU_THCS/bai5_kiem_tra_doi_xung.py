def is_palindrome_number(n):
    s = str(abs(int(n)))
    return s == s[::-1]

if __name__ == '__main__':
    print(is_palindrome_number(121))  # True
    print(is_palindrome_number(123))  # False
