# Lambda để kiểm tra một số có phải là dương hay không
is_positive = lambda x: (x > 0)

if __name__ == '__main__':
    print(is_positive(5))   # True
    print(is_positive(-1))  # False
