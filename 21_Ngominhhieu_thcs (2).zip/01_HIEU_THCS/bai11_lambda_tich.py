# Lambda để tính tích của ba số bất kỳ
product_three = lambda x, y, z: x * y * z

if __name__ == '__main__':
    print(product_three(2,3,4))  # 24
