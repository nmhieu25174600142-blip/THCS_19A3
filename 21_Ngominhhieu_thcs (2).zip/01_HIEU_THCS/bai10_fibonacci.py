def fibonacci(n):
    """Trả về số Fibonacci thứ n (quy ước fibonacci(1)=0, fibonacci(2)=1)"""
    n = int(n)
    if n <= 0:
        raise ValueError('n phải là số nguyên dương')
    if n == 1:
        return 0
    if n == 2:
        return 1
    a, b = 0, 1
    for _ in range(3, n+1):
        a, b = b, a + b
    return b

if __name__ == '__main__':
    print(fibonacci(1))  # 0
    print(fibonacci(6))  # 5 (0,1,1,2,3,5)
