# BTVN Chương 9 - Mã nguồn
Các bài toán được tách thành các file Python riêng (bai1_..., bai2_..., ...).

Hướng dẫn nộp:
- Đặt tên thư mục theo cú pháp: STT_HOTEN_THCS (ví dụ: 01_HIEU_THCS)
- Mỗi bài ở trong file riêng, chạy `python baiX_...py` để kiểm tra.

