def giai_pt_bac_nhat(a, b):
    """Giải phương trình ax + b = 0. Trả về nghiệm hoặc chuỗi thông báo."""
    if a == 0:
        if b == 0:
            return 'Vô số nghiệm'
        else:
            return 'Vô nghiệm'
    return -b / a

if __name__ == '__main__':
    print(giai_pt_bac_nhat(2, -4))  # 2.0
    print(giai_pt_bac_nhat(0,0))   # 'Vô số nghiệm'
