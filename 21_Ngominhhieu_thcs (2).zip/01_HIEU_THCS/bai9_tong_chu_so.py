def sum_digits(n):
    return sum(int(d) for d in str(abs(int(n))))

if __name__ == '__main__':
    print(sum_digits(12345))  # 15
