import math

def is_prime(n):
    n = int(n)
    if n < 2:
        return False
    if n <= 3:
        return True
    if n % 2 == 0:
        return False
    r = int(math.isqrt(n))
    for i in range(3, r+1, 2):
        if n % i == 0:
            return False
    return True

def primes_in_range(a, b):
    a, b = int(a), int(b)
    if a > b:
        a, b = b, a
    return [x for x in range(max(2,a), b+1) if is_prime(x)]

if __name__ == '__main__':
    print(is_prime(17))  # True
    print(primes_in_range(10, 30))
