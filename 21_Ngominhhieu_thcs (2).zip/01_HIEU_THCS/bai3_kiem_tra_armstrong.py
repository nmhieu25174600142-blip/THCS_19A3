def is_armstrong(n):
    """Kiểm tra số Armstrong (ví dụ: 153 = 1^3+5^3+3^3)."""
    s = str(abs(int(n)))
    power = len(s)
    total = sum(int(d)**power for d in s)
    return total == abs(int(n))

if __name__ == '__main__':
    print(is_armstrong(153))  # True
    print(is_armstrong(154))  # False
