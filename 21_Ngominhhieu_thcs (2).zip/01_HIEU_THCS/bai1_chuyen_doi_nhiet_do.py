def c_to_f(celsius):
    """Chuyển đổi nhiệt độ từ độ C sang độ F"""
    return celsius * 9/5 + 32

if __name__ == '__main__':
    # ví dụ
    print(c_to_f(0))   # 32.0
    print(c_to_f(100)) # 212.0
