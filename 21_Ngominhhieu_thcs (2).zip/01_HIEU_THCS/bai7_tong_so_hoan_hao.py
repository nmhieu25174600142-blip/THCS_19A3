def sum_perfect_numbers(a, b):
    a, b = int(a), int(b)
    if a > b:
        a, b = b, a

    def is_perfect(n):
        if n <= 1:
            return False
        s = 1
        i = 2
        while i * i <= n:
            if n % i == 0:
                s += i + (n // i if i * i != n else 0)
            i += 1
        return s == n

    total = 0
    found = []
    for x in range(a, b+1):
        if is_perfect(x):
            found.append(x)
            total += x
    return total, found

if __name__ == '__main__':
    print(sum_perfect_numbers(1, 10000))  # (6+28+496+8128 = ...), will also list them
