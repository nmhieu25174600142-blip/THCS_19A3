# Lambda để kiểm tra một số có phải là chẵn hay không (True/False)
is_even = lambda x: (int(x) % 2 == 0)

if __name__ == '__main__':
    print(is_even(4))  # True
    print(is_even(5))  # False
