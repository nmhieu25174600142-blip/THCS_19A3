# Lambda để tính tổng hai số
sum_two = lambda x, y: x + y

if __name__ == '__main__':
    print(sum_two(3,4))  # 7
