from bai6_so_nguyen_to import is_prime, primes_in_range

def check_and_print(n):
    n = int(n)
    print(f"{n} là số nguyên tố: {is_prime(n)}")
    primes_100_500 = primes_in_range(100, 500)
    print("Các số nguyên tố trong khoảng [100, 500]:")
    print(primes_100_500)
    return is_prime(n), primes_100_500

if __name__ == '__main__':
    check_and_print(17)
